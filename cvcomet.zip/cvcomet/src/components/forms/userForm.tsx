"use client";

import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/redux/store";
import { addUser } from "@/redux/user/userSlice";
import { useTranslation } from 'react-i18next';

const loginSchema = z.object({
  email: z.string().email({ message: "Email invalide" }),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function LoginPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });
  const dispatch = useDispatch<AppDispatch>();

  const onSubmit = async (data: LoginForm) => {
    dispatch(addUser(data));
    router.push("/");
  };

  return (
    <div className="flex items-center justify-center">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="rounded-xl w-full"
      >

        <label
          htmlFor="email"
          className="block mb-2 text-sm font-medium text-foreground"
        >
          Email
        </label>
        <input
          id="email"
          type="email"
          {...register("email")}
          className={`w-full border rounded-lg px-3 py-2 mb-1 focus:outline-none focus:ring-2 ${errors.email ? "border-red-500 focus:ring-red-500" : "focus:ring-blue-500"
            }`}
        />
        {errors.email && (
          <p className="text-destructive text-sm mb-4">{errors.email.message}</p>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full mt-4 bg-primary text-primary-foreground font-semibold py-2 rounded-lg hover:bg-primary transition disabled:opacity-50"
        >
          {isSubmitting ? "Loading..." : "Login"}
        </button>
      </form>
    </div>
  );
}
